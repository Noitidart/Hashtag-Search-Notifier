import React, { Component } from 'react'
import { Animated, TextInput, View, Dimensions } from 'react-native'

import { compareIntThenLex } from 'cmn/all'

import styles from './style.css'

const STATUS = {
    HIDING: 'HIDING',
    HIDDEN: 'HIDDEN',
    SHOWING: 'SHOWING',
    SHOWN: 'SHOWN'
}

// `option` is object { label:string, value:any } // link811727627

/* props
    containeStyle? - ReactNativeStyle; default:undefined;
    ...pickerProps // crossfile-link4167643
*/
function PickerOverlayHOC(WrappedComponent, props) {
    return class PickerOverlayHOC extends Component {
        state = {
            anim: new Animated.Value(0),
            status: STATUS.HIDDEN,
            name: '', //
            options: [], // array of `options`
            selectedValues: {}, // key is "options set" `name` passed to `show`
            term: null // string; term to filter by
        }
        componentDidUpdate(propsOld, stateOld) {
            const { status, anim } = this.state;
            const { status:statusOld } = stateOld;

            if (status !== statusOld) {
                if (status === STATUS.HIDING) {
                    Animated.timing(anim).start( () =>
                        this.setState( () => ({ status:STATUS.HIDDEN }) )
                    );
                } else if (status === STATUS.SHOWING) {
                    Animated.spring(anim).start( () =>
                        this.setState( () => ({ status:STATUS.SHOWN }) )
                    );
                }
            }
        }
        render() {
            const { status } = this.state;
            if (status === STATUS.HIDDEN) return null;

            const { name, selectedValues, options, anim } = this.state;
            const { show, hide, select } = this;
            const picker = { values, show };

            const selectedValue = selectedValues[name];

            const { containerStyle, ...pickerProps } = props;

            const pickerContainerStyle = {
                transform: [
                    {
                        translateY: Animated.interpolate({
                            from: [0, 1],
                            to: [Dimensions.get('screen').height, 0]
                        })
                    }
                ]
            };

            return (
                <View style={[styles.container, containerStyle]}>
                    <Animated.View style={[styles.pickerContainer, pickerContainerStyle]}>
                        <Picker {...pickerProps} selectedValue={selectedValue} options={options} hide={hide} select={select} name={name} />
                    </Animated.View>
                    <WrappedComponent picker={picker} />
                </View>
            )
        }
        show = (name, title, options=[]) => {
            // name - string; name of "options set"
            // title - PickerProp
            // options can be
                // state.options array
                // array of values - the label will be value.toString() - if the .toString() comes out non-unique a react error/warn will be thrown for duplicate key on render of options list, this is why i dont test for duplicates - crossfile-link4411190
                // object of { [label1]:value1, ... } - will get sorted asc by sortLexThenInt by label
                // immutable OrderedMap

            // correct options to array of `options`
            if (!Array.isArray(options)) {

            } else {
                if (!isOptions(options)) {
                    const values = options;
                    options = values.map( value => [{ label:value.toString(), value:value }] ); // crossfile-link4411190
                }
            }
        }
        hide = () => {

        }
        select = (name, label) => {

        }
    }
}

function isOptions(arr) {
    // returns true if arr is an array of objects

    if (!Array.isArray(arr)) return false;
    if (!arr.length) return false;

    // check if shape of `option` - link811727627
    const keys = Object.keys(arr[0]);
    if (keys.length !== 2) return false;
    const keysNeeded = ['label', 'value']
    if (keysNeeded.includes(keys[0]) && keysNeeded.includes(keys[1])) return true;
    return false
}

export default PickerOverlayHOC