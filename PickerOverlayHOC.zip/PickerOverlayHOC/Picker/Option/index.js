import React, { PureComponent } from 'react'
import { View } from 'react-native'

import styles from './style.css'

/* props
select - func
selected? - bool; default:false
selectedLabelStyle - ReactNativeStyle; default:undefined;
selectedLabel? - string; default:"&middot;"
label - string
name - string
*/
class Option extends PureComponent {
    render() {
        const { selected=false, selectedLabel='&middot;', selectedLabelStyle, label } = this.props;

        return (
            <View style={styles.option}>
                { selected &&
                    <View style={styles.selected}>
                        <Text style={[styles.selectedText, selectedLabelStyle]}>{selectedLabel}</Text>
                    </View>
                }
                <View style={styles.label}>
                    <Text style={styles.labelText}>{label}</Text>
                </View>
            </View>
        )
    }
    handlePress = () => {
        const { select, name, label } = this.props;

        select(name, label);
    }
}

export default Option