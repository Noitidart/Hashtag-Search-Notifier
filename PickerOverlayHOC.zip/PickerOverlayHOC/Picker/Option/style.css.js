import { StyleSheet } from 'react-native'

const styles = {
    option: {},
    selected: {},
    selectedText: {},
    label: {},
    labelText: {}
}

export default styles