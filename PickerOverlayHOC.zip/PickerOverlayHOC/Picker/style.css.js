import { StyleSheet } from 'react-native'

const styles = {
    picker: {
        height: '70%',
        width: '80%'
    },
    header: {},
    title: {},
    close: {},
    closeText: {},
    filterRow: {},
    filterInput: {},
    clear: {},
    clearText: {},
    options: {}
}

export default styles