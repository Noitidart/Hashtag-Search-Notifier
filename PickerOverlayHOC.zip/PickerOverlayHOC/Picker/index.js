import React from 'react'
import { Text, View } from 'react-native'

import { escapeRegex } from 'cmn/all'

import styles from './style.css'

/* props
selectedValue? - string that occours in options - if it doesnt occur it is as if "undefined" but warning will show
options - array of option's
select - func
hide - func
term - string
termChangeHandler - func
name
// devuser props - crossfile-link4167643
title? - string; default:undefined;
closeLabelStyle? - ReactNativeStyle; default:undefined;
closeLabel? - string; default:"X";
clearLabelStyle - ReactNativeStyle; default:undefined;
clearLabel - string; default:"X";
*/

const Picker = ({ selectedValue, options, select, closeLabel='X', clearLabel='X', name }) => (
    <View style={styles.picker}>
        <View style={styles.header}>
            { title && <Text style={styles.title}>{title}</Text> }
            <View style={styles.close}>
                <Text style={[styles.closeText, closeLabelStyle]}>{closeLabel}</Text>
            </View>
        </View>
        <View style={styles.filterRow}>
            <TextInput style={styles.filterInput} value={term} onChange={termChangeHandler} />
            <View style={styles.clear}>
                <Text style={[styles.clearText, clearLabelStyle]}>{clearLabel}</Text>
            </View>
        </View>
        <View style={styles.options}>
            { renderOptions(options, term, selectedValue, selectedLabelStyle, name, select) }
        </View>

    </View>
)

function renderOptions(options, term, selectedValue, selectedLabelStyle, name, select) {
    if (term) {
        const termPatt = new RegExp(escapeRegex(term), 'i');
        options = options.filter( ({ label }) => label.test(termPatt) );
    }

    // key for duplicate label error/warn will be here - crossfile-link4411190
    return options.map( ({ label, value }) =>
        <Option key={label} label={label} value={value} selected={value === selectedValue} selectedLabelStyle={value === selectedValue && selectedLabelStyle} name={name} select={select} />
    )
}